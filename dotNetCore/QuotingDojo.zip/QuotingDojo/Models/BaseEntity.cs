namespace QuotingDojo.Models
{
    public abstract class BaseEntity {}
}